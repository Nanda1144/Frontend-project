<meta name='viewport' content='width=device-width, initial-scale=1'/><script>function changeColor() {
      const button = document.getElementById('colorButton');
      
      if (button.style.backgroundColor === 'red') {
        button.style.backgroundColor = 'blue';
      } else {
        button.style.backgroundColor = 'red';
      }
    }</script>