<meta name='viewport' content='width=device-width, initial-scale=1'/><style>body{
  font-family: Arial, sans-serif;
  background-color : skyblue;
}
h1{
  color : yellow;
}
p{
  color: red;
}
li{
  color: red;
}

form{
 
  width: 300px;
  padding: 20px;
  border: 1px solid black;
  border-radius : 10px;
}

</style><script>function greetingTime() {
      const presentHour= new Date().getHours(); 

      if (presentHour < 12) {
        alert('Good Morning!');
      } else if (presentHour < 18) {
        alert('Good Afternoon!');
      } else {
        alert('Good Evening!');
      }
    }
    greetingTime();</script>