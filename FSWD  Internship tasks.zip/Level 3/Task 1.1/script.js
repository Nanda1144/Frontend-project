<meta name='viewport' content='width=device-width, initial-scale=1'/><script>
function openModal() {
    document.getElementById("modal").style.display = "block";
  }
function closeModal() {
    document.getElementById("modal").style.display = "none";
}

function currentSlide(n) {
    let slides = document.getElementsByClassName("modal-slide");
    for (let i = 0; i < slides.length; 
    i++) {
        slides[i].style.display = "none";
    }
    slides[n-1].style.display = "block";
}
</script>